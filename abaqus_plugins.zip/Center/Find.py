from abaqus import *
from abaqusConstants import *
import math
import numpy as np

def calculate_circle_center(p1, P2, P3):
    p1 = np.array(p1.coordinates)
    p2 = np.array(P2.coordinates)
    p3 = np.array(P3.coordinates)
    

    v1 = p2 - p1
    v2 = p3 - p1
    normal = np.cross(v1, v2)
    normal = normal / np.linalg.norm(normal)  
    

    mid12 = (p1 + p2) / 2
    mid13 = (p1 + p3) / 2
    

    dir12 = np.cross(normal, v1)
    dir13 = np.cross(normal, v2)
    
   
    
    A = np.column_stack((dir12, -dir13))
    b = mid13 - mid12
    
 
    t = np.linalg.lstsq(A, b, rcond=None)[0]
    

    center = mid12 + t[0] * dir12
    

    radius = np.linalg.norm(center - p1)

    
    model_names = list(mdb.models.keys())
    if not model_names:
        raise ValueError("No model")
    current_model_name = model_names[0]

    model = mdb.models[current_model_name]

    a = mdb.models['Model-1'].rootAssembly
    
    ref_point = a.ReferencePoint(point=tuple(center))

    return (ref_point)